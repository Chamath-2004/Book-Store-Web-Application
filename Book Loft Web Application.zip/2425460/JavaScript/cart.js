document.addEventListener('DOMContentLoaded', function () {
    // Load cart items and counters from localStorage
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    let cartCounter = parseInt(localStorage.getItem('cartCounter')) || 0;

    // Reset cartCounter to 0 if there are no items in the cart
    if (cartItems.length === 0) {
        cartCounter = 0;
        localStorage.setItem('cartCounter', cartCounter); // Save to localStorage
    }

    // Function to update the cart counter
    function updateCartCounter() {
        document.getElementById('cart-counter').textContent = cartCounter;
        localStorage.setItem('cartCounter', cartCounter); // Save to localStorage
    }

    // Function to show the cart panel
    function showCartPanel() {
        console.log('Cart panel is being shown'); // Debugging
        const cartPanel = document.getElementById('cart-panel');
        if (cartPanel) {
            cartPanel.classList.add('active');
        } else {
            console.error('Cart panel element not found');
        }
    }

    // Function to hide the cart panel
    function hideCartPanel() {
        const cartPanel = document.getElementById('cart-panel');
        if (cartPanel) {
            cartPanel.classList.remove('active');
        }
    }

    // Function to update the cart panel
function updateCartPanel() {
    const cartItemsList = document.getElementById('cart-items');
    if (cartItemsList) {
      cartItemsList.innerHTML = '';
      let total = 0;
  
      cartItems.forEach((item, index) => {
        const li = document.createElement('li');
        li.innerHTML = `
          <span>${item.title} (${item.category}) - LKR ${item.price} x ${item.quantity}</span>
          <button onclick="removeItem(${index})">
          <img src="../images/icons8-bin-16.png" alt="Remove">
          </button>
        `;
        cartItemsList.appendChild(li);
        total += item.price * item.quantity;
      });
  
      const cartTotal = document.getElementById('cart-total');
      if (cartTotal) {
        cartTotal.textContent = `LKR ${total.toFixed(2)}`;
      }
      localStorage.setItem('cartItems', JSON.stringify(cartItems)); // Save to localStorage
    } else {
      console.error('Cart items list not found');
    }
  }

    // Function to add item to cart
    function addToCart(book) {
        const existingItem = cartItems.find(item => item.id === book.id && item.category === book.category);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cartItems.push({ ...book, quantity: 1 });
        }
        cartCounter += 1;
        updateCartCounter();
        updateCartPanel();
        showCartPanel();
    }

    // Function to remove item from cart
    window.removeItem = function (index) {
        cartCounter -= cartItems[index].quantity;
        cartItems.splice(index, 1);
        updateCartCounter();
        updateCartPanel();
    };

    // Event listeners for add to cart buttons
    const cartButtons = document.querySelectorAll('.cart-btn');
    if (cartButtons.length > 0) {
        cartButtons.forEach(button => {
            button.addEventListener('click', function () {
                const bookElement = this.closest('.book-categories'); // Use closest() to find the book container
                if (bookElement) {
                    const book = {
                        id: bookElement.getAttribute('data-id'),
                        category: bookElement.getAttribute('data-category'), // Include category
                        title: bookElement.getAttribute('data-title'),
                        price: parseFloat(bookElement.getAttribute('data-price'))
                    };
                    addToCart(book);
                } 
            });
        });
    } 
    // Event listener for close cart button
    const closeCartButton = document.getElementById('close-cart');
    if (closeCartButton) {
        closeCartButton.addEventListener('click', hideCartPanel);
    } else {
        console.error('Close Cart button not found');
    }

    // Event listener for checkout button
    const checkoutButton = document.getElementById('view-cart');
    if (checkoutButton) {
        checkoutButton.addEventListener('click', function () {
            window.location.href = '../HTML/add_to_cart.html'; // Redirect to checkout page
        });
    } else {
        console.error('Checkout button not found');
    }
    
    
    // Sort books
    const sortOptions = document.querySelectorAll('input[name="sort"]');
    sortOptions.forEach(option => {
        option.addEventListener('change', function () {
            const sortBy = this.value;
            const bookGrid = document.getElementById('bookGrid');
            const books = Array.from(bookGrid.children);

            books.sort((a, b) => {
                const aPrice = parseFloat(a.getAttribute('data-price'));
                const bPrice = parseFloat(b.getAttribute('data-price'));
                const aRating = parseFloat(a.querySelector('p:nth-of-type(2)').textContent.split(': ')[1]);
                const bRating = parseFloat(b.querySelector('p:nth-of-type(2)').textContent.split(': ')[1]);

                if (sortBy === 'price-low') return aPrice - bPrice;
                if (sortBy === 'price-high') return bPrice - aPrice;
                if (sortBy === 'rating') return bRating - aRating; // Sort from high to low
                return 0;
            });

            bookGrid.innerHTML = '';
            books.forEach(book => bookGrid.appendChild(book));
        });
    });

    // Initialize counters and cart panel on page load
    updateCartCounter();
    updateCartPanel();


    // Initialize counters and cart panel on page load
    updateCartCounter();
    updateCartPanel();
    
   

    
    
});

