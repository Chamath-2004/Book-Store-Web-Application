document.addEventListener("DOMContentLoaded", function () {
    // Get the book ID from the URL query parameter
    const urlParams = new URLSearchParams(window.location.search);
    const bookId = urlParams.get('id'); // e.g., book-detail.html?id=1
  
    if (!bookId) {
      console.error("Book ID not found in URL.");
      return;
    }
  
    // Fetch the XML file
    fetch("../XML/reviews.xml")
      .then(response => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.text();
      })
      .then(data => {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(data, "text/xml");
  
        // Find the book with the specified ID
        const book = xmlDoc.querySelector(`book[id="${bookId}"]`);
  
        if (book) {
          // Extract book details
          const title = book.querySelector("title").textContent;
          const category = book.querySelector("category").textContent;
          const price = book.querySelector("price").textContent;
          const image = book.querySelector("image").textContent;
          const description = book.querySelector("description").textContent;
          const language = book.querySelector("language").textContent;
          const author = book.querySelector("author").textContent;
          const publisher = book.querySelector("publisher").textContent;
          const isbn = book.querySelector("isbn").textContent;
          const rating = book.querySelector("rating").textContent;
          const stock = book.querySelector("stock").textContent;
  
          // Update the <title> tag with the book title
          document.title = `${title} | Book Loft`; 

          // Populate the book details in the HTML
          document.getElementById("book-title").textContent = title;
          document.getElementById("book-price").textContent = `LKR ${price}`;
          document.getElementById("book-stock").textContent = stock;
          document.getElementById("book-language").textContent = language;
          document.getElementById("book-author").textContent = author;
          document.getElementById("book-publisher").textContent = publisher;
          document.getElementById("book-isbn").textContent = isbn;
          document.getElementById("book-category").textContent = category;
          document.getElementById("book-rating").textContent = rating;
          document.getElementById("book-description").textContent = description;
          document.getElementById("book-image").src = image; 
  
          // Set the data-* attributes dynamically
          const bookInformation = document.querySelector('.book-information');
          bookInformation.setAttribute('data-id', bookId);
          bookInformation.setAttribute('data-category', category);
          bookInformation.setAttribute('data-title', title);
          bookInformation.setAttribute('data-price', price);
  
          // Add event listener for the "Add to Cart" button
          const addToCartButton = document.querySelector('.cart-btn');
          if (addToCartButton) {
            addToCartButton.addEventListener('click', addToCart);
          }
  
          // Add event listener for the "Buy Now" button
          const buyNowButton = document.getElementById('buy-now');
          if (buyNowButton) {
            buyNowButton.addEventListener('click', buyNow);
          }
        } else {
          console.error("Book not found in XML data.");
        }
      })
      .catch(error => {
        console.error("Error fetching book details:", error);
      });
  });
  
  // Function to update the quantity
  window.updateQuantity = function (change) {
    const quantityInput = document.getElementById('quantity');
    let quantity = parseInt(quantityInput.value);
    quantity += change;
    if (quantity < 1) quantity = 1; // Ensure quantity is at least 1
    quantityInput.value = quantity;
  };
  
  // Function to add item to cart
  function addToCart() {
    const bookElement = document.querySelector('.book-information');
    const quantity = parseInt(document.getElementById('quantity').value);
  
    // Get book details from the data-* attributes
    const book = {
      id: bookElement.getAttribute('data-id'),
      category: bookElement.getAttribute('data-category'),
      title: bookElement.getAttribute('data-title'),
      price: parseFloat(bookElement.getAttribute('data-price')),
      quantity: quantity,
      image: document.getElementById('book-image').src,
    };
  
    // Retrieve existing cart items from localStorage
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
  
    // Check if the item already exists in the cart
    const existingItem = cartItems.find(item => item.id === book.id && item.category === book.category);
    if (existingItem) {
      existingItem.quantity += book.quantity; // Update quantity if item exists
    } else {
      cartItems.push(book); // Add new item to cart
    }
  
    // Save updated cart items to localStorage
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
  
    // Update cart counter
    let cartCounter = parseInt(localStorage.getItem('cartCounter')) || 0;
    cartCounter += quantity;
    localStorage.setItem('cartCounter', cartCounter);
    document.getElementById('cart-counter').textContent = cartCounter;
  
    // Update the cart panel (if it exists)
    updateCartPanel();
    showCartPanel();
  
    alert('Item added to cart!');
  }
  
  // Function to handle "Buy Now" button
  function buyNow() {
    // If the quantity is not set, default to 1
    const quantityInput = document.getElementById('quantity');
    const quantity = quantityInput.value ? parseInt(quantityInput.value) : 1;
  
    // Add the item to the cart with the default or selected quantity
    const bookElement = document.querySelector('.book-information');
    const book = {
      id: bookElement.getAttribute('data-id'),
      category: bookElement.getAttribute('data-category'),
      title: bookElement.getAttribute('data-title'),
      price: parseFloat(bookElement.getAttribute('data-price')),
      quantity: quantity,
      image: document.getElementById('book-image').src,
    };
  
    // Retrieve existing cart items from localStorage
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
  
    // Check if the item already exists in the cart
    const existingItem = cartItems.find(item => item.id === book.id && item.category === book.category);
    if (existingItem) {
      existingItem.quantity += book.quantity; // Update quantity if item exists
    } else {
      cartItems.push(book); // Add new item to cart
    }
  
    // Save updated cart items to localStorage
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
  
    // Update cart counter
    let cartCounter = parseInt(localStorage.getItem('cartCounter')) || 0;
    cartCounter += quantity;
    localStorage.setItem('cartCounter', cartCounter);
    document.getElementById('cart-counter').textContent = cartCounter;
  
    // Open the add to cart.html page in a new tab
    window.open('../HTML/add_to_cart.html', '_blank');
  }
  
  // Function to update the cart panel
  function updateCartPanel() {
    const cartItemsList = document.getElementById('cart-items');
    if (cartItemsList) {
      cartItemsList.innerHTML = '';
      let total = 0;
  
      const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
      cartItems.forEach((item, index) => {
        const li = document.createElement('li');
        li.innerHTML = `
          <span>${item.title} (${item.category}) - LKR ${item.price.toFixed(2)} x ${item.quantity}</span>
          <button onclick="removeItem(${index})">
          <img src="../images/icons8-bin-16.png" alt="Remove">
          </button>
        `;
        cartItemsList.appendChild(li);
        total += item.price * item.quantity;
      });
  
      const cartTotal = document.getElementById('cart-total');
      if (cartTotal) {
        cartTotal.textContent = `LKR ${total.toFixed(2)}`;
      }
    }
  }
  
  // Function to show the cart panel
  function showCartPanel() {
    const cartPanel = document.getElementById('cart-panel');
    if (cartPanel) {
      cartPanel.classList.add('active');
    }
  }
  
  // Function to remove item from cart
  window.removeItem = function (index) {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    let cartCounter = parseInt(localStorage.getItem('cartCounter')) || 0;
  
    cartCounter -= cartItems[index].quantity;
    cartItems.splice(index, 1);
  
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    localStorage.setItem('cartCounter', cartCounter);
    document.getElementById('cart-counter').textContent = cartCounter;
  
    updateCartPanel();
  };